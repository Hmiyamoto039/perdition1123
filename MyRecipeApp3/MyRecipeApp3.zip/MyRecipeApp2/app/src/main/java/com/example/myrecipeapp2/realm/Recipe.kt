package com.example.myrecipeapp2.realm


import io.realm.DynamicRealm
import io.realm.RealmMigration
import io.realm.RealmObject
import io.realm.RealmSchema
import io.realm.annotations.PrimaryKey

open class Recipe : RealmObject() {
    @PrimaryKey
    var id :Long = 0
    var recipeTitle :String = ""
    var recipeDetail :String = ""
    var recipeTag :String =""
    var toDayCheck :Boolean = false
}