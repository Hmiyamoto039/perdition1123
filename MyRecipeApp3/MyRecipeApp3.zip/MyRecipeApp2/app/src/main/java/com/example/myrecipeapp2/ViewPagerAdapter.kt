package com.example.myrecipeapp2

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.myrecipeapp2.recipe.RecipeFragment
import com.example.myrecipeapp2.today.TodayFragment

class ViewPagerAdapter (fa:FragmentActivity):FragmentStateAdapter(fa){

    private val fragments = listOf(
        TodayFragment(),
        RecipeFragment()
    )

    override fun getItemCount(): Int = fragments.size

    override fun createFragment(position: Int): Fragment {
        return fragments[position]
    }

}