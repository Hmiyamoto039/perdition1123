package com.example.myrecipeapp2.realm

import android.app.Application
import android.content.Intent
import io.realm.Realm
import io.realm.RealmConfiguration
import kotlin.system.exitProcess

class RecipeApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        Realm.init(this)

        val config = RealmConfiguration.Builder()
            .schemaVersion(1L)
            .migration(MyMigration())
            .allowQueriesOnUiThread(true)
            .allowWritesOnUiThread(true)
            .build()

        Realm.setDefaultConfiguration(config)

    }

}